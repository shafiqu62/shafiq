from app import myApp
from flask import render_template, request

@myApp.route('/')
def index():
    return render_template('index.html')

@myApp.route('/login')
def login():
    return render_template('login.html')

@myApp.route('/teacher')
def teacher():
    return render_template('teacher.html')

@myApp.route('/admin')
def admin():
    return render_template('admin.html')

@myApp.route('/signup')
def signup():
    return render_template('signup.html')

@myApp.route('/student')
def student():
    return render_template('student.html')

@myApp.route('/users')
def users():
    return render_template('users.html')

@myApp.route('/test1', methods=["POST", "GET"])
def signup():
    # print(request.form['username'])

    if request.method == "POST":
        user1 = User()
        user1.name = request.form['username']
        user1.password = request.form['pass']
        db.session.add(user1)
        db.session.commit()

    return render_template('signup.html')
@myApp.route('/test1', methods=["POST", "GET"])
def admin():
    # print(request.form['username'])

    if request.method == "POST":
        user2 = User()
        user2.name = request.form['username']
        user2.password = request.form['pass']
        user2.city = request.form['city']
        user2.id = request.form['id']
        db.session.add(user2)
        db.session.commit()

    return render_template('admin.html')

@myApp.route('/test1', methods=["POST", "GET"])
def student():
    # print(request.form['username'])

    if request.method == "POST":
        user3 = User()
        user3.name = request.form['username']
        user3.password = request.form['pass']
        user3.rollno = request.form['roll no']
        db.session.add(user3)
        db.session.commit()

    return render_template('student.html')

@myApp.route('/test1', methods=["POST", "GET"])
def teacher():
    # print(request.form['username'])

    if request.method == "POST":
        user4 = User()
        user4.name = request.form['username']
        user4.password = request.form['pass']
        user4.id = request.form['id']
        db.session.add(user4)
        db.session.commit()

    return render_template('teacher.html')